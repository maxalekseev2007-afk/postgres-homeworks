# Skypro — Введение в БД: North

Проект уже содержит три CSV-файла из задания в папке `north_data`.

## Состав проекта

- `create_tables.sql` — создаёт таблицы `employees`, `customers`, `orders` и связи.
- `main.py` — загружает данные из CSV в PostgreSQL через `psycopg2`.
- `north_data/` — исходные CSV-файлы.
- `requirements.txt` — зависимость для Python.

## Как запустить

1. Установи PostgreSQL и pgAdmin.
2. Создай базу данных с именем `north`.
3. В pgAdmin выбери базу `north` → Tools → Query Tool.
4. Открой `create_tables.sql` и выполни весь скрипт.
5. Убедись, что у пользователя PostgreSQL `postgres` пароль `0210`. Если при установке задан другой пароль, поменяй его в `main.py`.
6. Открой терминал в папке проекта и выполни:

   ```bash
   python -m venv .venv
   ```

   Windows:
   ```bash
   .venv\Scripts\activate
   ```

   Затем:
   ```bash
   pip install -r requirements.txt
   python main.py
   ```

## Проверка

В Query Tool базы `north` выполни:

```sql
SELECT COUNT(*) FROM employees;
SELECT COUNT(*) FROM customers;
SELECT COUNT(*) FROM orders;

SELECT * FROM employees LIMIT 10;
SELECT * FROM customers LIMIT 10;
SELECT * FROM orders LIMIT 10;
```

Связи между таблицами:
- `orders.customer_id` → `customers.customer_id`
- `orders.employee_id` → `employees.employee_id`

Повторный запуск не создаёт дубликаты по первичным ключам.
