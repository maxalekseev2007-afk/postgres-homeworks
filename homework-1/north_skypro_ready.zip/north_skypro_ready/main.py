"""Загрузка employees_data.csv, customers_data.csv и orders_data.csv в PostgreSQL."""

import csv
import os
import psycopg2
from psycopg2 import sql

# Пароль установлен по просьбе пользователя.
DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "dbname": "north",
    "user": "postgres",
    "password": "0210",
}

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "north_data")

FILES = {
    "employees": "employees_data.csv",
    "customers": "customers_data.csv",
    "orders": "orders_data.csv",
}

PRIMARY_KEYS = {
    "employees": "employee_id",
    "customers": "customer_id",
    "orders": "order_id",
}


def read_csv(filename):
    """Читает CSV UTF-8 с заголовками."""
    path = os.path.join(DATA_DIR, filename)
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Не найден файл: {path}")

    with open(path, "r", encoding="utf-8-sig", newline="") as file:
        reader = csv.DictReader(file)
        if not reader.fieldnames:
            raise ValueError(f"В файле {filename} отсутствуют заголовки.")
        rows = []
        for row in reader:
            # CSV заголовки совпадают с именами колонок в таблицах.
            rows.append({
                key.strip(): (value.strip() if value is not None and value.strip() != "" else None)
                for key, value in row.items()
                if key is not None
            })
        return rows


def import_table(cursor, table_name):
    filename = FILES[table_name]
    rows = read_csv(filename)

    # Используем только колонки, которые реально есть в таблице PostgreSQL.
    cursor.execute(
        """
        SELECT column_name
        FROM information_schema.columns
        WHERE table_schema = 'public' AND table_name = %s
        ORDER BY ordinal_position
        """,
        (table_name,),
    )
    table_columns = {row[0] for row in cursor.fetchall()}
    if not table_columns:
        raise RuntimeError(
            f"Таблица {table_name} не найдена. Сначала выполни create_tables.sql в базе north."
        )

    inserted = 0
    for row_number, row in enumerate(rows, start=2):
        values_by_column = {
            key: value for key, value in row.items()
            if key in table_columns
        }
        primary_key = PRIMARY_KEYS[table_name]
        if not values_by_column.get(primary_key):
            raise ValueError(
                f"В файле {filename}, строка {row_number}: отсутствует {primary_key}."
            )

        columns = list(values_by_column.keys())
        query = sql.SQL(
            "INSERT INTO {} ({}) VALUES ({}) ON CONFLICT ({}) DO NOTHING"
        ).format(
            sql.Identifier(table_name),
            sql.SQL(", ").join(sql.Identifier(column) for column in columns),
            sql.SQL(", ").join(sql.Placeholder() for _ in columns),
            sql.Identifier(primary_key),
        )
        cursor.execute(query, [values_by_column[column] for column in columns])
        inserted += cursor.rowcount

    print(f"{table_name}: прочитано {len(rows)}, добавлено {inserted} записей.")


def main():
    if not os.path.isdir(DATA_DIR):
        raise FileNotFoundError(f"Не найдена папка north_data: {DATA_DIR}")

    connection = None
    try:
        connection = psycopg2.connect(**DB_CONFIG)
        with connection:
            with connection.cursor() as cursor:
                # Сначала сотрудники и клиенты, затем заказы из-за внешних ключей.
                import_table(cursor, "employees")
                import_table(cursor, "customers")
                import_table(cursor, "orders")
        print("Готово! Все данные загружены в базу north.")
    except Exception as error:
        if connection is not None:
            connection.rollback()
        print(f"Ошибка загрузки: {error}")
        raise
    finally:
        if connection is not None:
            connection.close()


if __name__ == "__main__":
    main()
